سورس ديف فايدر العربي الجديد 🌝🚶
احدث سورس بالتلي 🕵🖖

💠- افتح ترمنال جديد وخلي 😍👇

sudo apt-get update

🌀- عوفه مفتوح وفتح ترمنال لاخ وخلي 😍👇

sudo apt-get install libreadline-dev libconfig-dev libssl-dev lua5.2 liblua5.2-dev lua-socket lua-sec lua-expat libevent-dev make unzip git redis-server autoconf g++ libjansson-dev libpython-dev expat libexpat1-dev

➿- وراهه 😍👇

git clone https://github.com/faederhb11/Feader.git

🚼- وراهه😍👇

cd Feader

☢- وراهه😍👇

chmod +x launch.sh

🔄- وراهه😍👇

./launch.sh install

☯- وراهه😍👇

./launch.sh

💟- بعدها يطلب رقم ودخل ررقم ومبروك عليك البوت 💞🍃

🕎- بعدها افتح ترمنال جديد واكتب😕 👇

sudo service redis-server start

♈️- ودوس انتر

🈳- وسوي رن من ملف لانج

السورس من تطوير
⏬↔️⏬↔️⏬↔️⏬↔️⏬↔️⏬
💯-Đєⱴ💀 : @xXxDev_iqxXx
💯-Đєⱴ💀 : @hamapaiz
💯-Đєⱴ💀 : @X_x_56_GaHaNaM_56_x_X
💯-Đєⱴ💀 : بوت التواصل  @D_e_v_faeder_bot
💯-Đєⱴ💀قناة السورس @Dev_faed
