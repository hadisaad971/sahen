do 

function run(msg, matches) 
  return [[ 
✋Ⱳاوامر سورس 🚫┆فايـﮩٰٰہـدر🔱̴
🃏〰〰〰〰👑〰〰〰〰〰🃏

 ♻ اوامر  ═╬═ ᗨ   ♻

♨ م1: لعرض الاوامر الرئيسية🌏

♨ م2:لعرض الاوامر الثانويه🃏

♨ م3:لعرض اوامرحمايةالمجموعه🛃

 📍 م4:لعرض اوامر التحكم بالميديا➿

👑 م المطور : لعرض اوامر المطور👑

💳قناه السورس 💳  @Dev_faed

🔰〰〰〰〰〰المطور〰〰〰〰🔰
♻-Đєⱴ💀 @xXxDev_iqxXx
♻Đєⱴ 😎 @hamapaiz
♻Đєⱴ 📛 @X_x_56_GaHaNaM_56_x_X
💥 Đєⱴ🔥 @D_e_v_faeder_bot
]] 

end 

return { 
description = "Help list", 
usage = "Help list", 
patterns = { 
"^(الاوامر)$", 
}, 
run = run 
} 
end
