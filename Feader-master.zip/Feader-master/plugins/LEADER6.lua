--[[
▄ ▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀          
▀▄ ▄▀                                                ▀▄ ▄▀ 
▀▄ ▄▀       BY ANWAR     @xXxDev_iqxXx          ▀▄ ▄▀ 
▀▄ ▄▀ BY MOHAMMED LEADER  @Hamapaiz          ▀▄ ▄▀          
▀▄ ▄▀ BY         CHNEALL     @Dev_faed           ▀▄ ▄▀   
▀▄ ▄▀                  المطورين السورس               ▀▄ ▄▀ 
▀▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀

--]]
do

function run(msg, matches)
return [[

االبوت الذي يعمل على مجوعات السوبر 🔺

يعمل البوت على مجموعات سوبر تصل الى 5 k عضو 🔺

     ≪تم صنع البوت بواسطة المطور≫
                      『  @xXxDev_iqxXx  』
                      
             🔻 LEADER : @hamapaiz 🔺
                      
                      🔺 تابعونا ماهو كل جديد على قناه السورس 🔻
                      
                      [ @Dev_faed ]
                      
      🔺 للاستفسار :-  @X_x_56_GaHaNaM_56_x_X   🔻
                     
          🔻 DEV:- @D_e_v_faeder_bot  🔺
                     
                     🔻  SUPPORTBOT :- @Dev_faed. 🔺
]]
end

return {
description = "Shows bot q", 
usage = "spam Shows bot q",
patterns = {
"^(المطور)$",
},
run = run 
}
end