--[[ 
▀▄ ▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀          
▀▄ ▄▀                                      ▀▄ ▄▀ 
▀▄ ▄▀    BY faeder                         ▀▄ ▄▀ 
▀▄ ▄▀     BY faeder(@xXxDev_iqxXx)         ▀▄ ▄▀ 
▀▄ ▄▀ JUST WRITED BY faeder                ▀▄ ▄▀   
▀▄ ▄▀          dev1  : dev                 ▀▄ ▄▀ 
▀▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀
--]]
do

function run(msg, matches)
return [[

االبوت الذي يعمل على مجوعات السوبر 🔸

يعمل البوت على مجموعات سوبر تصل الى5k عضو 🔷

     ≪تم صنع البوت بواسطة المطور≫
                      『 @xXxDev_iqxXx 』
            
            『  تواصل @D_e_v_faeder_bot』
            
            『 CH > @Dev_faed』
]]
end

return {
description = "Shows bot q", 
usage = "spam Shows bot q",
patterns = {
"مطور البوت$"
},
run = run 
}
end
