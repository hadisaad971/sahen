--[[ 
▀▄ ▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀▄▀▄▄▀▀▄▄▀▀▄▄▀▀▄▄▀▀          
▀▄ ▄▀                                      ▀▄ ▄▀ 
▀▄ ▄▀    BY faeder                         ▀▄ ▄▀ 
▀▄ ▄▀     BY faeder (@xXxDev_iqxXx)        ▀▄ ▄▀ 
▀▄ ▄▀ Making the file by faeder            ▀▄ ▄▀   
▀▄ ▄▀          reply  :  تكرار الكلام       ▀▄ ▄▀ 
▀▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀▄▄▀▀▄▄▀▄▄▀▀
--]]
local function ii02ii(msg,matches)
local Memo = matches[2]
return Memo
end

  return  {
    patterns = {
      "^(كول)(.+)",
       "^(اكول)(.+)",
        "^(يكول)(.+)",
},
  run = ii02ii,
}
-- BY Dev #Memo - @II02II 
-- بداعت امك لتحذف الحقول